# Diwali wishing

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aryan-Awasthi/pen/zYgjryQ](https://codepen.io/Aryan-Awasthi/pen/zYgjryQ).

